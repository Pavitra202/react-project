import addItem from "./addItem";
import { combineReducers } from "redux";

const rootReducers = combineReducers({
    addItem
})

export default rootReducers;
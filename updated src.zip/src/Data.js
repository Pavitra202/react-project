const Data=[

    {
    id:1,
    title:"Short Sleeves Jumpsuit ",
    price:820,
    desc:" Ikeda Designs Printed Short Sleeves Jumpsuit With Ruffles - Pink 4 to 5 Years, The outfit that'll provide utmost comfort to your baby.",
    img :"/assets/images/products/img1.png"
    },
    {
    id:2,
    title:"Carter's Reindeer Jersey Tee - Green ",
    price:755,
    desc:"Carter's is the leading brand of children's clothing, 5 to 6 Years, (Carter's size:5-6T), Comfy round neck tee for boys ",
    img :"/assets/images/products/img2.png"
    },
    {
    id:3,
    title:"Kookie Kids Full Sleeves Frock with Bow",
    price:607,
    desc:"Kookie Kids aims at offering exclusivity at its best with its extensive range of quality products that showcase a blend of International taste and comfort for children.12 to 18 Months, (Size 90), Trendy round neck frock for girls",
    img :"/assets/images/products/img3.png"
    },
    {
    id:4,
    title:"Babyoye Full Sleeves Frock Floral Patch ",
    price:780.00,
    desc:" Babyoye 'super-cute must haves' are designed to capture the magic of childhood, making perfect memories for the cute little adventurers. 12 to 18 Months, snug round neck frock with back button closure for girls",
    img :"/assets/images/products/img4.png"
    },
    {
    id:5,
    title:"Babyhug Full Sleeves Hooded Jacket ",
    price:"649",
    desc:"Babyhug is India's largest and most trusted baby care brand. When it comes to the needs of their little ones, countless mums can vouch for the convenience, safety, and quality that is synonymous with Babyhug. ",
    img :"/assets/images/products/img5.png"
    },
    {
    id:6,
    title:"Carter's 2-Piece Dinosaur Button-Front Shirt & Pant Set",
    price:805,
    desc:"Carter's is the leading brand of children's clothing, gifts and accessories in America, selling more than 10 products for every child born in the U.S.",
    img:"/assets/images/products/img6.png"
    
    
    
    },
    {
    id:7,
    title:"Babyoye Cotton Full Sleeves Pullover Sweater ",
    price:701,
    desc:"6 to 9 Months, warm and comfortable front zip placket sweater for boys",
    img:"/assets/images/products/img7.png"
    
    
    
    },
    {
    id:8,
    title:"Babyhug Full Sleeves Woollen Dress Polka Dot Print",
    price:769,
    desc:"9 to 12 Months, Stylish round neck dress with shoulder buttons for girls",
    img:"/assets/images/products/img8.png"
    },
    {
    id:18,
    title:"Babyhug Full Sleeves Hooded Sweatshirt Reversible Sequinned Football ",
    price:450,
    desc:"3 to 4 Years, hooded, pullover style sweatshirt for boys",
    img:"/assets/images/products/img18.png"
    },
    {
    id:16,
    title:"Babyhug Full Sleeves Hooded Sweatshirt - Grey ",
    price:550,
    desc:"12 to 18 Months, Stylish hooded neck sweatshirt for boys",
    img:"/assets/images/products/img16.png"
    },
    {
    id:9,
    title:"Ollington St. Flutter Sleeves Top & Culottes Floral Print ",
    price:710,
    desc:"Ollington St. is a fashion sets and suits brand that offers top and bottom as a set for kids between 2-10Y. The brand erases the need for parents to make clothing combinations for their kids.",
    img:"/assets/images/products/img9.png"
    },
    {
    id:17,
    title:"Babyhug Striped Dungaree with Half Sleeves Inner Tee Firefighter Embroidery",
    price:789,
    desc:"12 to 18 Months, round neck tee with pull up style dungaree for boys",
    img:"/assets/images/products/img17.png"
    },
    {
    id:10,
    title:"Babyhug Milk Protein Formula Daily Head To Toe Milky Wash - 100 ml ",
    price:97,
    desc:"Babyhug Milky wash is derived from natural ingredients that gently cleanse and moisturise baby's delicate skin and hair. It contains Milk Protein, Aloe Vera & Wheat Germ Oil that nourish, moisturise and prevent the risk of dryness after the wash. ",
    img:"/assets/images/products/img10.png"
    },
    {
    id:11,
    title:"Babyhug Advanced Talc-Free Dusting Powder - 100 gm ",
    price:100,
    desc:"Babyhug dusting powder is formulated with natural extracts which absorbs moisture on baby's skin naturally. This powder is talc free and hypoallergenic in nature. Naturally derived maize starch provides a gentle way to soothe your baby's skin and leave it feeling soft, smooth, and comfortable. ",
    img:"/assets/images/products/img11.png"
    },
    {
    id:12,
    title:"Babyhug Bunny Design Shampoo Rinse Cup- Pink ",
    price:144,
    desc:"Babyhug is India's largest and most trusted baby care brand. When it comes to the needs of their little ones, countless mums can vouch for the convenience, safety, and quality that is synonymous with Babyhug.",
    img:"/assets/images/products/img12.png"
    },
    {
    id:13,
    title:"Babyhug Bath Sponge - Light Pink ",
    price:195,
    desc:"3 to 12 Months, L 10 x B 7 x H 11 cm, Soft and durable loofah for luxurious bath time",
    img:"/assets/images/products/img13.png"
    },
    {
    id:14,
    title:"Babyhug Daily Rich Moisturising Milky Soap - 75 gm",
    price:90,
    desc:"Babyhug milky soap is derived from natural ingredients that gently cleanse and moisturize baby's delicate skin. It contains milk Protein, aloe vera & wheat Germ oil that nourishes, moisturizes and prevents the risk of dryness after the wash. ",
    img:"/assets/images/products/img14.png"
    },
    {
    id:15,
    title:"Babyhug Foldable Bathtub with Cushion - Blue Beige",
    price:2372,
    desc:"Create a safe, relaxing environment for your baby each time you bathe them in this bath tub. Made from safe and durable material with soft curved edges that make baby bath time easy and comfortable for your little one.",
    img:"/assets/images/products/img15.png"
    },
    {
    id:19,
    title:"YAMAMA Bump and Go Toy Train Locomotive Engine Car with Lights and Sounds - Multicolor ",
    price:739,
    desc:"Ideal Age 0 to 24 Months, L 22 x B 8 x H 11 cm, Develops motor skills, A perfect new addition to your little ones collection of cars and trucks",
    img:"/assets/images/products/img19.png"
    },
    {
    id:20,
    title:"NEGOCIO Friction Power Airplane - Color May Vary ",
    price:819,
    desc:"All new funny air plane model plane toy with friction power, light & music dream flight for babies, kids, toddlers, infants. It is friction powered air plane toy with and is made of quality ABS plastic material and well constructed.",
    img:"/assets/images/products/img20.png"
    },
    {
    id:21,
    title:"EYESIGN Blaze Storm Soft Bullet Automatic Gun - Multicolour",
    price:3119,
    desc:"Blaze storm soft bullet gun series has long shooting range with great fun, easy to operate, also has strong and quick chamber switching function and quick shooting ability.",
    img:"/assets/images/products/img21.png"
    },
    {
    id:22,
    title:"Rising Step 4 Function Chargeable Race Car - Blue ",
    price:1147,
    desc:"t's almost every young boy's dream to become race car driver one day! Watch your child's eyes light up with amazement when you gift him this race car from rising step. This life-like toy comes with a remote control and even has working headlights and rear lights. ",
    img:"/assets/images/products/img22.png"
    },
    {
    id:23,
    title:"ToyMark Musical Talking Tom Toy White ",
    price:880,
    desc:"ToyMark is committed to provide genuine and best in class products in toys, baby products and gifts category. ",
    img:"/assets/images/products/img23.png"
    },
    {
    id:24,
    title:"Fiddlerz Mermaid Doll Height 35 cm (Colour May Vary) ",
    price:550,
    desc:"These plush toys are very cute, you can lay them on the sofa or relax with it, very suitable for relaxing sleep. Stuffed Toys are super soft, adorable, and unabashedly cute!Which are created with an ultra-premium, child-friendly, and high-density plush material for maximum softness, weight, and quality you can sense at first touch. multipurpose plush toys makes for an adorable companionship for any child. ",
    img:"/assets/images/products/img24.png"
    }
    
    
    
    
    
    ]
    export default Data